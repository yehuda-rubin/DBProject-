--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4 (Debian 17.4-1.pgdg120+2)
-- Dumped by pg_dump version 17.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE mydatabase;
--
-- Name: mydatabase; Type: DATABASE; Schema: -; Owner: myuser
--

CREATE DATABASE mydatabase WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE mydatabase OWNER TO myuser;

\connect mydatabase

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ammunition; Type: TABLE; Schema: public; Owner: myuser
--

CREATE TABLE public.ammunition (
    id integer NOT NULL,
    type character varying NOT NULL,
    location_id integer NOT NULL,
    quantity character varying(50) NOT NULL,
    date_add date NOT NULL
);


ALTER TABLE public.ammunition OWNER TO myuser;

--
-- Name: approved; Type: TABLE; Schema: public; Owner: myuser
--

CREATE TABLE public.approved (
    id_p integer NOT NULL,
    id_i integer NOT NULL,
    id_a integer NOT NULL
);


ALTER TABLE public.approved OWNER TO myuser;

--
-- Name: inspections; Type: TABLE; Schema: public; Owner: myuser
--

CREATE TABLE public.inspections (
    ammo_id integer NOT NULL,
    inspection_date date NOT NULL,
    id integer NOT NULL,
    status character varying(50) NOT NULL
);


ALTER TABLE public.inspections OWNER TO myuser;

--
-- Name: inventorymovement; Type: TABLE; Schema: public; Owner: myuser
--

CREATE TABLE public.inventorymovement (
    ammo_id integer NOT NULL,
    inspention_date date NOT NULL,
    id integer NOT NULL
);


ALTER TABLE public.inventorymovement OWNER TO myuser;

--
-- Name: moved_by; Type: TABLE; Schema: public; Owner: myuser
--

CREATE TABLE public.moved_by (
    id_a integer NOT NULL,
    id_im integer NOT NULL,
    id_o integer NOT NULL
);


ALTER TABLE public.moved_by OWNER TO myuser;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: myuser
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    ammo_id integer NOT NULL,
    from_location_id integer NOT NULL,
    to_movement_id integer NOT NULL
);


ALTER TABLE public.orders OWNER TO myuser;

--
-- Name: personnel; Type: TABLE; Schema: public; Owner: myuser
--

CREATE TABLE public.personnel (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    email character varying(50) NOT NULL,
    phone_number integer NOT NULL,
    role character varying(50) NOT NULL
);


ALTER TABLE public.personnel OWNER TO myuser;

--
-- Name: places; Type: TABLE; Schema: public; Owner: myuser
--

CREATE TABLE public.places (
    id_o integer NOT NULL,
    id_a integer NOT NULL
);


ALTER TABLE public.places OWNER TO myuser;

--
-- Name: sorted_in; Type: TABLE; Schema: public; Owner: myuser
--

CREATE TABLE public.sorted_in (
    id_sl integer NOT NULL,
    id_p integer NOT NULL,
    id_a integer NOT NULL
);


ALTER TABLE public.sorted_in OWNER TO myuser;

--
-- Name: storagelocation; Type: TABLE; Schema: public; Owner: myuser
--

CREATE TABLE public.storagelocation (
    location_name character varying(50) NOT NULL,
    location_type character varying(50) NOT NULL,
    id integer NOT NULL
);


ALTER TABLE public.storagelocation OWNER TO myuser;

--
-- Data for Name: ammunition; Type: TABLE DATA; Schema: public; Owner: myuser
--

COPY public.ammunition (id, type, location_id, quantity, date_add) FROM stdin;
\.
COPY public.ammunition (id, type, location_id, quantity, date_add) FROM '$$PATH$$/3421.dat';

--
-- Data for Name: approved; Type: TABLE DATA; Schema: public; Owner: myuser
--

COPY public.approved (id_p, id_i, id_a) FROM stdin;
\.
COPY public.approved (id_p, id_i, id_a) FROM '$$PATH$$/3429.dat';

--
-- Data for Name: inspections; Type: TABLE DATA; Schema: public; Owner: myuser
--

COPY public.inspections (ammo_id, inspection_date, id, status) FROM stdin;
\.
COPY public.inspections (ammo_id, inspection_date, id, status) FROM '$$PATH$$/3426.dat';

--
-- Data for Name: inventorymovement; Type: TABLE DATA; Schema: public; Owner: myuser
--

COPY public.inventorymovement (ammo_id, inspention_date, id) FROM stdin;
\.
COPY public.inventorymovement (ammo_id, inspention_date, id) FROM '$$PATH$$/3422.dat';

--
-- Data for Name: moved_by; Type: TABLE DATA; Schema: public; Owner: myuser
--

COPY public.moved_by (id_a, id_im, id_o) FROM stdin;
\.
COPY public.moved_by (id_a, id_im, id_o) FROM '$$PATH$$/3428.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: myuser
--

COPY public.orders (id, ammo_id, from_location_id, to_movement_id) FROM stdin;
\.
COPY public.orders (id, ammo_id, from_location_id, to_movement_id) FROM '$$PATH$$/3423.dat';

--
-- Data for Name: personnel; Type: TABLE DATA; Schema: public; Owner: myuser
--

COPY public.personnel (id, name, email, phone_number, role) FROM stdin;
\.
COPY public.personnel (id, name, email, phone_number, role) FROM '$$PATH$$/3425.dat';

--
-- Data for Name: places; Type: TABLE DATA; Schema: public; Owner: myuser
--

COPY public.places (id_o, id_a) FROM stdin;
\.
COPY public.places (id_o, id_a) FROM '$$PATH$$/3430.dat';

--
-- Data for Name: sorted_in; Type: TABLE DATA; Schema: public; Owner: myuser
--

COPY public.sorted_in (id_sl, id_p, id_a) FROM stdin;
\.
COPY public.sorted_in (id_sl, id_p, id_a) FROM '$$PATH$$/3427.dat';

--
-- Data for Name: storagelocation; Type: TABLE DATA; Schema: public; Owner: myuser
--

COPY public.storagelocation (location_name, location_type, id) FROM stdin;
\.
COPY public.storagelocation (location_name, location_type, id) FROM '$$PATH$$/3424.dat';

--
-- Name: ammunition ammunition_pkey; Type: CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.ammunition
    ADD CONSTRAINT ammunition_pkey PRIMARY KEY (id);


--
-- Name: approved approved_pkey; Type: CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.approved
    ADD CONSTRAINT approved_pkey PRIMARY KEY (id_p, id_i);


--
-- Name: inspections inspections_pkey; Type: CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.inspections
    ADD CONSTRAINT inspections_pkey PRIMARY KEY (id);


--
-- Name: inventorymovement inventorymovement_pkey; Type: CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.inventorymovement
    ADD CONSTRAINT inventorymovement_pkey PRIMARY KEY (id);


--
-- Name: moved_by moved_by_pkey; Type: CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.moved_by
    ADD CONSTRAINT moved_by_pkey PRIMARY KEY (id_a, id_im, id_o);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: personnel personnel_pkey; Type: CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.personnel
    ADD CONSTRAINT personnel_pkey PRIMARY KEY (id);


--
-- Name: places places_pkey; Type: CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.places
    ADD CONSTRAINT places_pkey PRIMARY KEY (id_o, id_a);


--
-- Name: sorted_in sorted_in_pkey; Type: CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.sorted_in
    ADD CONSTRAINT sorted_in_pkey PRIMARY KEY (id_p, id_a);


--
-- Name: storagelocation storagelocation_pkey; Type: CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.storagelocation
    ADD CONSTRAINT storagelocation_pkey PRIMARY KEY (id);


--
-- Name: approved approved_id_a_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.approved
    ADD CONSTRAINT approved_id_a_fkey FOREIGN KEY (id_a) REFERENCES public.ammunition(id);


--
-- Name: approved approved_id_i_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.approved
    ADD CONSTRAINT approved_id_i_fkey FOREIGN KEY (id_i) REFERENCES public.inspections(id);


--
-- Name: approved approved_id_p_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.approved
    ADD CONSTRAINT approved_id_p_fkey FOREIGN KEY (id_p) REFERENCES public.personnel(id);


--
-- Name: moved_by moved_by_id_a_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.moved_by
    ADD CONSTRAINT moved_by_id_a_fkey FOREIGN KEY (id_a) REFERENCES public.ammunition(id);


--
-- Name: moved_by moved_by_id_im_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.moved_by
    ADD CONSTRAINT moved_by_id_im_fkey FOREIGN KEY (id_im) REFERENCES public.inventorymovement(id);


--
-- Name: moved_by moved_by_id_o_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.moved_by
    ADD CONSTRAINT moved_by_id_o_fkey FOREIGN KEY (id_o) REFERENCES public.orders(id);


--
-- Name: places places_id_a_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.places
    ADD CONSTRAINT places_id_a_fkey FOREIGN KEY (id_a) REFERENCES public.ammunition(id);


--
-- Name: places places_id_o_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.places
    ADD CONSTRAINT places_id_o_fkey FOREIGN KEY (id_o) REFERENCES public.orders(id);


--
-- Name: sorted_in sorted_in_id_a_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.sorted_in
    ADD CONSTRAINT sorted_in_id_a_fkey FOREIGN KEY (id_a) REFERENCES public.ammunition(id);


--
-- Name: sorted_in sorted_in_id_p_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.sorted_in
    ADD CONSTRAINT sorted_in_id_p_fkey FOREIGN KEY (id_p) REFERENCES public.personnel(id);


--
-- Name: sorted_in sorted_in_id_sl_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.sorted_in
    ADD CONSTRAINT sorted_in_id_sl_fkey FOREIGN KEY (id_sl) REFERENCES public.storagelocation(id);


--
-- PostgreSQL database dump complete
--

