import random

with open("insert_orders.sql", "w") as f:
    for order_id in range(1, 401):  # 400 orders
        ammo_id = random.randint(1, 400)
        from_location_id = random.randint(1, 400)
        to_movement_id = random.randint(1, 400)

        query = (
            f"INSERT INTO Orders (id, ammo_id, from_Location_id, to_movement_id) "
            f"VALUES ({order_id}, {ammo_id}, {from_location_id}, {to_movement_id});\n"
        )
        f.write(query)

