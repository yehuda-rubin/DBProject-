import random

places_set = set()

with open("insert_places.sql", "w") as f:
    while len(places_set) < 400:
        id_o = random.randint(1, 400)  # Order ID
        id_a = random.randint(1, 400)  # Ammo ID

        key = (id_o, id_a)
        if key not in places_set:
            places_set.add(key)
            query = f"INSERT INTO places (id_o, id_a) VALUES ({id_o}, {id_a});\n"
            f.write(query)


