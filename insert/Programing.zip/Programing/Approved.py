import random

approved_set = set()

with open("insert_approved.sql", "w") as f:
    while len(approved_set) < 400:
        id_p = random.randint(1, 100)  # בהנחה שיש 100 אנשי צוות
        id_i = random.randint(1, 100)  # בהנחה שיש 100 בדיקות
        id_a = random.randint(1, 100)  # בהנחה שיש 100 סוגי תחמושת

        key = (id_p, id_i)
        if key not in approved_set:
            approved_set.add(key)
            query = f"INSERT INTO Approved (id_p, id_i, id_a) VALUES ({id_p}, {id_i}, {id_a});\n"
            f.write(query)

print("קובץ insert_approved.sql נוצר בהצלחה!")
